from django.test import TestCase
from django.urls import reverse
from django.urls import resolve
from ..views import signup

